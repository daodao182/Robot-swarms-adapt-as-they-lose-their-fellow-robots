import random as rd

from deap import base
from deap import creator
from deap import tools
import numpy as np
from pylab import *
import colorsys
# vars you can change
bits_size = 128
iterations = 48
minimize = True
virusSize = 8
intPopSize = 1000
carryingCapacity = 100


mutationRate = .3
rd.seed(64)
branchingFactor = 3

g = 0

# defalt
creator.create("FitnessMax", base.Fitness, weights=(-1.0 if minimize else 1.0,))
creator.create("Individual", list, fitness=creator.FitnessMax)
toolbox = base.Toolbox()
toolbox.register("attr_bool", rd.randint, 0, 1)
toolbox.register("individual", tools.initRepeat, creator.Individual, toolbox.attr_bool, bits_size)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)


def makePopulation(amount):
    return toolbox.population(n=amount)


virus = makePopulation(virusSize)
intPop = makePopulation(intPopSize)




def fitness1(individual, other):
    amount = 0
    for i in range(int(bits_size / 2)):
        if not (individual[i * 2] == other[i * 2] and individual[i * 2 + 1] == other[i * 2 + 1]):
            amount = amount + 1
    return amount

infomation = list()




def eval(individual):
    amount = min(map(lambda x: fitness1(individual, x), virus))
    return amount*amount*amount*amount,


def pprint(pop):
    par = len(set([ind.data[2] for ind in pop]))
    fits = [ind.fitness.values[0] for ind in pop]
    length = len(pop)
    mean = sum(fits) / length
    sum2 = sum(x * x for x in fits)
    std = abs(sum2 / length - mean ** 2) ** 0.5
    min_ = min(fits)
    print("  Min %s" % min_)
    print("  Max %s" % max(fits))
    print("  Avg %s" % mean)
    print("  Std %s" % std)
    print("  unique blood lines %s" % par)
    return min_, mean


fitsMin = bits_size



def testFitness(individual):
    individual.fitness.values = eval(individual)

toolbox.register("select", tools.selTournament, tournsize=3)
toolbox.register("evaluate", eval)
toolbox.register("mutate", tools.mutFlipBit, indpb=0.05)
fitnesses = map(toolbox.evaluate, intPop)
for ind, fit in zip(intPop, fitnesses):
    ind.fitness.values = fit

idofbcell=0

for individual  in intPop:
    idofbcell+=1
    individual.data = (0,idofbcell,0,idofbcell,ind.fitness.values[0])
    infomation.append((0,idofbcell,0,idofbcell,ind.fitness.values[0]))

pop = intPop
avgList = list()
while g < 42 and fitsMin != 0:

    g = g + 1

    offspring = toolbox.select(pop, len(pop))

    buildinglist = list()
    buildinglist+=offspring
    while len(buildinglist) < carryingCapacity:
        # print(random.choice(offspring))
        buildinglist.append(rd.choice(pop))


    # print(len(buildinglist))

    # print(buildinglist)
    offspring = list(map(toolbox.clone, buildinglist))

    for mutant in offspring:
        if rd.random() < mutationRate:
            idofbcell += 1
            mutant.data = (g, idofbcell, mutant.data[1], mutant.data[3],mutant.fitness.values[0])
            toolbox.mutate(mutant)
            infomation.append(mutant.data)
            del mutant.fitness.values

    # Evaluate the individuals with an invalid fitness
    invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
    fitnesses = map(toolbox.evaluate, invalid_ind)
    for ind, fit in zip(invalid_ind, fitnesses):
        ind.fitness.values = fit

    print("-- Generation %i --" % g)
    print("  number of changed Evaluated %i individuals" % len(offspring))

    fitsMin,avg=pprint(offspring)
    # t = sorted(offspring , key=lambda x :x.data[4])
    avgList.append(avg)
    # t = sorted((filter(lambda x :x.fitness.values[0]<=avg , offspring)), key=lambda x :x.fitness.values[0])
    print("  number of keeps %i" % len(t))
    pop = t[0:carryingCapacity]


print("-- End of (successful) evolution --")

fff = filter (lambda x :x[4]!=g,infomation)
#
#
# x = sorted(x , key=lambda x :x[0])
# print(x)
best_ind = min(infomation, key = lambda x: x[4])
avgList.append(best_ind[4])
# print("Best individual is %s, %s" % (best_ind,  eval(best_ind)))
print(best_ind)


yy = list(filter(lambda y: best_ind[3] == y[3], fff))
bloodlined = list()
last  = best_ind
bloodlined.append(best_ind)




for line in reversed(yy) :
    if(last[2] == line[1]):
        bloodlined.append(line)
        last=line

print(bloodlined)


#
# for x in infomation :
#     for y in infomation:
#         if y[1] == x[2]:
#             if math.sqrt(math.sqrt(avgList[y[0]])) > math.sqrt(math.sqrt(x[4])):
#                 ax.plot3D([math.sqrt(math.sqrt(y[4])), math.sqrt(math.sqrt(x[4]))],
#                           [math.sqrt(math.sqrt(avgList[y[0]])), math.sqrt(math.sqrt(avgList[x[0]]))], [y[0], x[0]],
#                           color=colorsys.hsv_to_rgb(.3 ,  ((y[0]) / (x[0])), 1/((avgList[y[0]]) / (x[4]))), linewidth=.5)
#             else:
#                 ax.plot3D([math.sqrt(math.sqrt(y[4])), math.sqrt(math.sqrt(x[4]))],
#                           [math.sqrt(math.sqrt(avgList[y[0]])), math.sqrt(math.sqrt(avgList[x[0]]))], [y[0], x[0]],
#                           color=colorsys.hsv_to_rgb(1, ((y[0]) / (x[0])), (avgList[y[0]]/ x[4]))
#                        , linewidth=.5)



for x in yy :
    for y in yy:
        if y[1] == x[2]:
            if math.sqrt(math.sqrt(avgList[y[0]])) > math.sqrt(math.sqrt(x[4])):
                ax.plot3D([math.sqrt(math.sqrt(y[4])), math.sqrt(math.sqrt(x[4]))],
                          [math.sqrt(math.sqrt(avgList[y[0]])), math.sqrt(math.sqrt(avgList[x[0]]))], [y[0], x[0]],
                          color=colorsys.hsv_to_rgb(.3 ,  ((y[0]) / (x[0])), 1/((avgList[y[0]]) / (x[4]))), linewidth=.5)
            else:
                ax.plot3D([math.sqrt(math.sqrt(y[4])), math.sqrt(math.sqrt(x[4]))],
                          [math.sqrt(math.sqrt(avgList[y[0]])), math.sqrt(math.sqrt(avgList[x[0]]))], [y[0], x[0]],
                          color=colorsys.hsv_to_rgb(1, ((y[0]) / (x[0])), (avgList[y[0]]/ x[4]))
                       , linewidth=.5)

for x in yy :
    for y in yy:
        if y[2] == x[1]:
            if (bloodlined.__contains__(x) and bloodlined.__contains__(y)) :
                ax.plot3D([math.sqrt(math.sqrt(y[4])), math.sqrt(math.sqrt(x[4]))],
                          [math.sqrt(math.sqrt(avgList[y[0]])), math.sqrt(math.sqrt(avgList[x[0]]))], [y[0], x[0]],
                          color=(0,0,1))




ax.set_ylabel('Avg fitness')
ax.set_zlabel('iterations')
ax.set_xlabel('Real fitness')
ax.invert_zaxis()
plt.show()
fig = plt.figure()



