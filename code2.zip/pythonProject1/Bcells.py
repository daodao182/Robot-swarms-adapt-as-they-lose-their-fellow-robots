
import random

from deap import base
from deap import creator
from deap import tools
import numpy as np
creator.create("FitnessMax", base.Fitness, weights=(-1.0,))
creator.create("Individual", list, fitness=creator.FitnessMax)

toolbox = base.Toolbox()

# Attribute generator
#                      define 'attr_bool' to be an attribute ('gene')
#                      which corresponds to integers sampled uniformly
#                      from the range [0,1] (i.e. 0 or 1 with equal
#                      probability)
toolbox.register("attr_bool", random.randint, 0, 1)
n=128


# Structure initializers
#                         define 'individual' to be an individual
#                         consisting of 100 'attr_bool' elements ('genes')
toolbox.register("individual", tools.initRepeat, creator.Individual,
    toolbox.attr_bool, n)


toolbox.register("population", tools.initRepeat, list, toolbox.individual)

virus = toolbox.population(n=1)[0]


def fitness(individual):
    sum = 0
    for child1, child2 in zip(virus, individual):
        sum = sum + (child1 ^ child2)
    return sum*sum*sum*sum,

toolbox.register("evaluate", fitness)
toolbox.register("mate", tools.cxTwoPoint)
toolbox.register("mutate", tools.mutFlipBit, indpb=0.05)
toolbox.register("select", tools.selTournament, tournsize=3)




def makePopulation(amount):
    return toolbox.population(n=amount)

CXPB, MUTPB = 0.3, 0.1



pop =makePopulation(1500)



def main():
    random.seed(64)




    # Evaluate the entire population


    print("  Evaluated %i individuals" % len(pop))
    g = 0


    while g < 42:
        # A new generation
        g = g + 1
        print("-- Generation %i --" % g)


        offspring = toolbox.select(pop, len(pop))  +makePopulation(len(pop))


        offspring = list(map(toolbox.clone, offspring))

        # Apply crossover and mutation on the offspring
        for child1, child2 in zip(offspring[::2], offspring[1::2]):
            if random.random() < CXPB:
                toolbox.mate(child1, child2)

                # fitness values of the children
                # must be recalculated later
                del child1.fitness.values
                del child2.fitness.values

        for mutant in offspring:

            # mutate an individual with probability MUTPB
            if random.random() < MUTPB:
                toolbox.mutate(mutant)
                del mutant.fitness.values

        # Evaluate the individuals with an invalid fitness
        invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        print(len(invalid_ind))
        fitnesses = map(toolbox.evaluate, invalid_ind)
        for ind, fit in zip(invalid_ind, fitnesses):
            ind.fitness.values = fit

        print("  Evaluated %i individuals" % len(invalid_ind))

        # The population is entirely replaced by the offspring


        # Gather all the fitnesses in one list and print the stats
        fits = [ind.fitness.values[0] for ind in pop]

        length = len(pop)
        mean = sum(fits) / length
        sum2 = sum(x*x for x in fits)
        std = abs(sum2 / length - mean**2)**0.5

        print("  Min %s" % min(fits))
        print("  Max %s" % max(fits))
        print("  Avg %s" % mean)
        print("  Std %s" % std)
        filtered=  list(filter(lambda x: x.fitness.values[0]<=mean,offspring))
        random.shuffle(filtered)
        print(" dfdfdd ",len(filtered))
        pop[:] = list(filtered[0:min(1000, len(filtered))])



    print("-- End of (successful) evolution --")

    best_ind = tools.selBest(pop, 1)[0]
    best_ind = tools.selBest(pop, 1)[-1]
    print(fitness(best_ind))

    print("Best individual is %s, %s" % (best_ind, best_ind.fitness.values))
if __name__ == "__main__":
    main()