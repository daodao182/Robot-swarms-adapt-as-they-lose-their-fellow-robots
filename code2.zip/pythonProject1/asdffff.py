from bitarray import bitarray
import random as rd
import math
import matplotlib.pyplot as plt1
from pylab import *
import colorsys
import numpy as np
rd.seed(6)




def calc(x):
    if x <= 3.1:
        return math.pow(20, x)
    elif 3 <= x <= 6:
        return -266.667 * math.pow(x, 5) + 6333.33 * math.pow(x, 4) - 59666.7 * math.pow(x, 3) + 278917 * math.pow(x,
                                                                                                                   2) - 647317 * x + 602500
    else:
        return max(10250 - (7775 * x) / 9 + (250 * math.pow(x, 2)) / 9 - (25 * math.pow(x, 3)) / 81, 0)


def PopulationMax(x):
    y = calc(x)
    return y + y*rd.uniform(-.05, .05)


def proabiltyOfMuations(x):
    if x <= 3:
        return 0
    elif x < 21:
        return 1.07533 - 0.295852 * x + 0.033784 * math.pow(x, 2) - 0.00163374 * math.pow(x,
                                                                                          3) + 0.0000281207 * math.pow(
            x, 4) + rd.uniform(-.05, .05)
    else:
        return .10


def meanfitness(x):
    if x < 3:
        return 0
    if x < 16:
        return -0.733333 + 0.337037 * x - 0.0285494 * math.pow(x, 2)+ 0.00113169 * math.pow(x, 3)- 0.0000171468  * math.pow(x, 4)
    else:
        x=16
        return -0.733333 + 0.337037 * x - 0.0285494 * math.pow(x, 2)+ 0.00113169 * math.pow(x, 3)- 0.0000171468  * math.pow(x, 4)


numeracids = 21
punishment = 1
bits = 6 * numeracids
viruses = 8
step=0.1
Hour8=1/3
islands = 100
# mutationRate = .1
maxMuation = 100
# initPop = 100
# make = 100
# keepBest=100
# keepnext =100
numberOfdays = 24
# shareInfo = False
# best = True


acug = {'a': bitarray('00'),
        'c': bitarray('01'),
        'u': bitarray('10'),
        'g': bitarray('11')}
acugbit = {bitarray('00').to01(): 'a',
           bitarray('01').to01(): 'c',
           bitarray('10').to01(): 'u',
           bitarray('11').to01(): 'g'}

ala = {'gcu', 'gcc', 'gca', 'gcg'}
arg = {'cgu', 'cgc', 'cga', 'cgg', 'aga', 'agg'}
asn = {'aau', 'aac'}
asp = {'gau', 'gac'}
cys = {'ugu', 'ugc'}
gln = {'caa', 'cag'}
glu = {'gaa', 'gag'}
gly = {'ggu', 'ggc', 'gga', 'ggg'}
his = {'cau', 'cac'}
lle = {'auu', 'auc', 'aua'}
start = {'aug'}
leu = {'uua', 'uug', 'cuu', 'cuc', 'cua', 'cug'}
lys = {'aaa', 'aag'}
met = {'aug'}
phe = {'uuu', 'uuc'}
pro = {'ccu', 'ccc', 'cca', 'ccg'}
ser = {'ucu', 'ucc', 'uca', 'ucg', 'agu', 'agc'}
thr = {'acu', 'acc', 'aca', 'acg'}
trp = {'ugg'}
tyr = {'uau', 'uac'}
val = {'guu', 'guc', 'gua', 'gug'}
stop = {'uag', 'uga', 'uaa'}

all = [ala, arg, asn, asp, cys, gln, glu, gly, his, lle, start, leu, lys, met, phe, pro, ser, thr, trp, tyr, val, stop]
mapacug = {}

for x in all:
    for y in x:
        mapacug[y] = x


def test111(a, b):
    if (not ((a) in mapacug[b])):
        return min(
            list(map(lambda z: len(list(filter(lambda x: not (x[0] == x[1]), zip(list(a), list(z))))), mapacug[b])))
    else:
        return 0


class bitArray:
    counter = 0

    def __init__(self, size, fitness=100000000000000000000, valid=False, array=None, iteration=0, parent=0, id=0,
                 parentid=0,virus = -1):

        bitArray.counter += 1
        self.fitness = fitness
        self.valid = valid
        self.size = size
        self.iteration = iteration
        self.virus= virus

        self.parentid = parentid
        if (id == 0):
            self.id = bitArray.counter
        else:
            self.id = id

        if (parent == 0):
            self.parent = bitArray.counter
        else:
            self.parent = parent

        if array == None:
            self.array = self.makeArray(size)
        else:
            self.array = array

    def makeArray(self, size):
        zero_count = rd.randint(0, size)
        one_count = size - zero_count
        my_list = [0] * zero_count + [1] * one_count
        rd.shuffle(my_list)
        return bitarray(''.join(map(str, my_list)))

    def flip(self, iteration):
        if(Hour8+self.iteration+ rd.uniform(-.5, .5)<iteration):
            return self
        self.iteration = iteration
        if self.valid:
            bitArray.counter += 1
            self.parentid = self.id
            self.id = bitArray.counter

        self.valid = False
        self.fitness = 10000000000000000
        loction = rd.randint(0, self.size / 2 - 1)
        self.array[loction * 2:loction * 2 + 2] = self.makeArray(2)

        return self

    def calcFitness2(self, others):
        self.valid = True

        arraySum = min(zip(list(map(lambda x: sum((self.array.__xor__(x.array)).tolist()), others)),range(viruses)),key= lambda  x:x[0])
        self.fitness = math.pow(arraySum[0], punishment)
        self.virus = arraySum[1]
        return self

    def calcFitness(self, others):
        return self.calcFitness1(others)

    def calcFitness1(self, others):

        self.valid = True
        y = [acugbit[self.array[i:i + 2].to01()] for i in range(0, bits, 2)]
        z = [''.join(y[i:i + 3]) for i in range(0, len(y), 3)]
        # arrayMin = min(
        #     list(map(lambda x: len(list(filter(lambda q: not ((q[1]) in mapacug[q[0]]), zip(x, z)))), others)))
        # # print(arrayMin)
        arrayMin = min(
            zip(list(map(lambda x: sum(list(map(lambda q: test111((q[1]), q[0]), zip(x, z)))), others)),
                range(viruses)),
            key=lambda x: x[0])
        self.fitness = math.pow(arrayMin[0], punishment)
        self.virus = arrayMin[1]


        self.fitness = self.fitness / (numeracids*3)
        return self

    def clone(self):
        return bitArray(self.size, fitness=self.fitness, valid=self.valid, array=self.array.copy(),
                        iteration=self.iteration, parent=self.parent, id=self.id, parentid=self.parentid
                        ,virus= self.virus )

    def __str__(self):
        return self.array


def makePopulation(amount, size, day):
    return [bitArray(size, iteration=day) for _ in range(amount)]

virus= makePopulation(viruses*viruses, bits,0)
rd.shuffle(virus)
virus = virus[0:viruses]
bitVirus = list(map(lambda y: [''.join(y[i:i + 3]) for i in range(0, len(y), 3)],
                    map(lambda x: [acugbit[x.array[i:i + 2].to01()] for i in range(0, bits, 2)], virus)))

populations = [list() for _ in range(islands)]

# avgList =list()
avgList = [list() for _ in range(islands)]
actions = [set() for _ in range(islands)]
infolist = [list() for _ in range(islands)]

closetvirus = [list() for _ in range(islands)]
numberOfMutaions = np.zeros(int(numberOfdays/step+1))


def pprint(pop, island):
    par = len(set([ind.parent for ind in pop]))
    virus = len(set([ind.virus for ind in pop]))
    fits = [ind.fitness for ind in pop]
    length = len(pop)
    mean = sum(fits) / length
    sum2 = sum(x * x for x in fits)
    std = abs(sum2 / length - mean ** 2) ** 0.5
    min_ = min(fits)
    max_ = max(fits)
    print("  Min %s" % min_)
    # print("  Max %s" % max_)
    print("  Avg %s" % mean)
    # print("  Std %s" % std)
    print("  unique blood lines %s" % par)
    infolist[island].append((virus))
    return mean


def tick(pop, day, popNumber):
    # newClones = [ind.clone() for ind in pop]
    storforlater = list()
    buildinglist = [ind.clone() for ind in pop]
    if day <= 3.1:

        buildinglist = sorted(filter(lambda x: x.fitness <= 1-meanfitness(day), buildinglist),
                              key=lambda x: x.fitness)
        while len(buildinglist) < PopulationMax(day):
            buildinglist += makePopulation(1, bits, day)

        storforlater= list(filter(lambda x: not x.valid, buildinglist))
        for i in storforlater:
            i.calcFitness(bitVirus)
            # actions[popNumber].add((i.parentid, i.id, day, i.fitness, i.parent))


    else:
        buildinglist = sorted(filter(lambda x: x.fitness <= 1-meanfitness(day), buildinglist),
                              key=lambda x: x.fitness)

        if len(buildinglist) > PopulationMax(day):
            buildinglist=buildinglist[0:min(int(PopulationMax(day)),len(buildinglist))]
            # for i in buildinglist[min(int(PopulationMax(day)),len(buildinglist)):-1]:
            #     i.calcFitness(bitVirus)
            #     # actions[popNumber].add((i.parentid, i.id, day, i.fitness, i.parent))


        while len(buildinglist) < PopulationMax(day):
            buildinglist.append(rd.choice(buildinglist))
        counter = 0
        for mutant in buildinglist:
            while (rd.random() < proabiltyOfMuations(day)) :
                mutant.flip(day)
                counter += 1

        numberOfMutaions[int(day / step)]+=counter

        storforlater = list(filter(lambda x: not x.valid, buildinglist))
        for i in storforlater:
            i.calcFitness(bitVirus)



        countSet= {}
        for i in buildinglist:
            if i.virus in countSet:
                countSet[i.virus] +=1
            else:
                countSet[i.virus]=1




    # buildinglist += [ind.clone() for ind in pop]

    mean = pprint(buildinglist, popNumber)
    for i  in storforlater:
        actions[popNumber].add((i.parentid, i.id, day, i.fitness, i.parent,mean))
    avgList[popNumber].append(mean)

    # offspring = sorted(buildinglist, key=lambda x: x.fitness)
    return buildinglist


it = 0
realit = 0
fitsMin = 1000000000



while it < numberOfdays and fitsMin != 0:
    populations = [tick(pop, it, popNumber) for pop, popNumber in zip(populations, range(islands))]
    it += step
    realit+=1
    print(it)
    # if (not (it < numberOfdays)):
    #
    #     for popNumber in range(islands):
    #         mean = pprint(populations[popNumber], popNumber)
    #         for i in populations[popNumber]:
    #             actions[popNumber].add((i.parentid, i.id, it, i.fitness, i.parent,mean))
    #         avgList[popNumber].append(pprint(populations[popNumber], popNumber))


print(list(map(lambda x : x[0],infolist[0])))